import { BrowserRouter } from "react-router-dom";
import CustomerNavBar from "./CustomerNavBar";  // ✅ since file is in src/
 
function App() {
  return (
    <BrowserRouter>
      <CustomerNavBar />
    </BrowserRouter>
  );
}

export default App;
