import { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';

export default function ViewAllCustomer() {
  const [customers, setCustomers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${config.url}/api/customer/viewall`);
      setCustomers(response.data);
      setError('');
    } catch (error) {
      if (error.response) {
        setError(error.response.data);
      } else {
        setError('Failed to fetch customers.');
      }
    }
  };

  return (
    <div>
      <h3 style={{ textAlign: "center", textDecoration: "underline" }}>All Customers</h3>

      {error && (
        <p style={{ textAlign: "center", color: "red", fontWeight: "bolder" }}>{error}</p>
      )}

      {customers.length > 0 ? (
        <table border="1" cellPadding="10" style={{ margin: "auto", marginTop: "20px", borderCollapse: "collapse" }}>
          <thead style={{ backgroundColor: "#f2f2f2" }}>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Gender</th>
              <th>Age</th>
              <th>Contact</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id}>
                <td>{c.id}</td>
                <td>{c.name}</td>
                <td>{c.gender}</td>
                <td>{c.age}</td>
                <td>{c.contact}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        !error && <p style={{ textAlign: "center" }}>No customers found.</p>
      )}
    </div>
  );
}
