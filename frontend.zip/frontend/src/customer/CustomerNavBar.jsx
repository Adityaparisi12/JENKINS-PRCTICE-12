import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function AddCustomer() {
  return <h2>Add Customer Page</h2>;
}

function ViewAllCustomer() {
  return <h2>View All Customers Page</h2>;
}

function UpdateCustomer() {
  return <h2>Update Customer Page</h2>;
}

function DeleteCustomer() {
  return <h2>Delete Customer Page</h2>;
}

export default function CustomerNavBar() {
  return (
    <Router>
      <div>
        {/* Navbar */}
        <nav style={{ backgroundColor: "#333", padding: "10px" }}>
          <ul style={{ display: "flex", listStyle: "none", margin: 0, padding: 0 }}>
            <li style={{ marginRight: "20px" }}>
              <Link to="/add-customer" style={{ color: "white", textDecoration: "none" }}>
                Add Customer
              </Link>
            </li>
            <li style={{ marginRight: "20px" }}>
              <Link to="/view-customers" style={{ color: "white", textDecoration: "none" }}>
                View All Customers
              </Link>
            </li>
            <li style={{ marginRight: "20px" }}>
              <Link to="/update-customer" style={{ color: "white", textDecoration: "none" }}>
                Update Customer
              </Link>
            </li>
            <li>
              <Link to="/delete-customer" style={{ color: "white", textDecoration: "none" }}>
                Delete Customer
              </Link>
            </li>
          </ul>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/add-customer" element={<AddCustomer />} />
          <Route path="/view-customers" element={<ViewAllCustomer />} />
          <Route path="/update-customer" element={<UpdateCustomer />} />
          <Route path="/delete-customer" element={<DeleteCustomer />} />
        </Routes>
      </div>
    </Router>
  );
}
