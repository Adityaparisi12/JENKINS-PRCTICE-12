const config =  
{ 
    "url":"http://localhost:1947" 
} 
 
export default config